:cite:`1986:lorenc`.
:footcite:`2009:mandel`.

.. bibliography::

.. footbibliography::
