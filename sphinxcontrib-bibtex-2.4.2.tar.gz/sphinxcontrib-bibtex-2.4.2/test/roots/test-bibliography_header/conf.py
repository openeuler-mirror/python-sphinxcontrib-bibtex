extensions = ['sphinxcontrib.bibtex']
exclude_patterns = ['_build']
bibtex_bibfiles = ['test.bib']
bibtex_bibliography_header = '.. rubric:: Regular Citations'
bibtex_footbibliography_header = '.. rubric:: Footnote Citations'
