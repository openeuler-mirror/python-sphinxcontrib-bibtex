:cite:`test1`
:cite:`test2`
:cite:`test3`
:cite:`test4`

.. bibliography::
   :style: plain
   :list: citation
   :all:
