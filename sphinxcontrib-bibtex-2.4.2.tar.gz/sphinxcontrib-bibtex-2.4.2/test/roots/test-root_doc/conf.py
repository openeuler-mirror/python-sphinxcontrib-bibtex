extensions = ['sphinxcontrib.bibtex']
exclude_patterns = ['_build']
bibtex_bibfiles = ['test.bib']
needs_sphinx = '4.0'
root_doc = 'root'  # only supported on Sphinx 4.0 and higher
