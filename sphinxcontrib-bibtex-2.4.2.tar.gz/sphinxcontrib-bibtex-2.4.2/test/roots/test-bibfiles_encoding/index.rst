:cite:`Test`

.. bibliography::
   :all:
