.. bibliography::
   :list: bullet
   :filter: author % "Second" and type == "misc"

.. toctree::

   or
   noteq
   lt
   lte
   gt
   gte
   key
   false
   true
   title
   in
   notin
   set
   bitand
   bitor
