True
----

.. bibliography::
   :list: bullet
   :filter: True
