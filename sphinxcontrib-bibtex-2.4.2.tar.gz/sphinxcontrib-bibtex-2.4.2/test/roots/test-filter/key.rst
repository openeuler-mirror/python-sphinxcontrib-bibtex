Key
---

.. bibliography::
   :list: bullet
   :filter: key == "third"
