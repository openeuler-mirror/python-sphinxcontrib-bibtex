Not In
------

.. bibliography::
   :list: bullet
   :filter: "bla" not in docnames
