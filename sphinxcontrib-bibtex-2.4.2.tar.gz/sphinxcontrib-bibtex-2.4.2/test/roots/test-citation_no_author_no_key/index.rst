:cite:p:`software_2015`
:cite:t:`software_2015`

:cite:p:`2009:mandel`
:cite:t:`2009:mandel`

:cite:p:`onlytitle`
:cite:t:`onlytitle`

:cite:p:`onlyeditor`
:cite:t:`onlyeditor`

.. bibliography::
