.. bibliography::
   :all:
   :cited:
   :notcited:
   :filter: author % "Troffaes"
