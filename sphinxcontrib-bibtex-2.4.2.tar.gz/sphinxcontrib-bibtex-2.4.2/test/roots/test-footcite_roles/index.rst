Contents
========

Single Citations
----------------

====================== ====================================================
role                   result
====================== ====================================================
``:footcite:p:``       :footcite:p:`testthree`
``:footcite:ps:``      :footcite:ps:`testthree`
``:footcite:t:``       :footcite:t:`testthree`
``:footcite:ts:``      :footcite:ts:`testthree`
``:footcite:ct:``      :footcite:ct:`testthree`
``:footcite:cts:``     :footcite:cts:`testthree`
====================== ====================================================

Double Citations
----------------

====================== ====================================================
role                   result
====================== ====================================================
``:footcite:p:``       :footcite:p:`testone,testtwo`
``:footcite:ps:``      :footcite:ps:`testone,testtwo`
``:footcite:t:``       :footcite:t:`testone,testtwo`
``:footcite:ts:``      :footcite:ts:`testone,testtwo`
``:footcite:ct:``      :footcite:ct:`testone,testtwo`
``:footcite:cts:``     :footcite:cts:`testone,testtwo`
====================== ====================================================

Triple Citations
----------------

====================== ====================================================
role                   result
====================== ====================================================
``:footcite:p:``       :footcite:p:`testfour,testfive,testsix`
``:footcite:ps:``      :footcite:ps:`testfour,testfive,testsix`
``:footcite:t:``       :footcite:t:`testfour,testfive,testsix`
``:footcite:ts:``      :footcite:ts:`testfour,testfive,testsix`
``:footcite:ct:``      :footcite:ct:`testfour,testfive,testsix`
``:footcite:cts:``     :footcite:cts:`testfour,testfive,testsix`
====================== ====================================================

.. footbibliography::
