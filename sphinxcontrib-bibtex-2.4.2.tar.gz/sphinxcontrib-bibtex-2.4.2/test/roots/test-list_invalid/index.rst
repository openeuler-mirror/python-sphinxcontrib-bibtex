.. bibliography::
   :list: thisisintentionallyinvalid
