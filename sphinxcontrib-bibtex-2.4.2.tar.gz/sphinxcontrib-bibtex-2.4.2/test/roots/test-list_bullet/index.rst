.. bibliography::
   :list: bullet
   :all:
