.. bibliography::
   :all:
