zdoc
----

Citation in a document that is processed only after the document containing the references
:cite:p:`2004:seidenfeld::rubinesque`.
