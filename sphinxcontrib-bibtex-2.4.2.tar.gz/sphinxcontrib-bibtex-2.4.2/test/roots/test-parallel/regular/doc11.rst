doc11
=====

:cite:`Sh:11`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
