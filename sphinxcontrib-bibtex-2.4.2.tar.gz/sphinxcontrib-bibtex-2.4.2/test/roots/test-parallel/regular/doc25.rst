doc25
=====

:cite:`Sh:25`

