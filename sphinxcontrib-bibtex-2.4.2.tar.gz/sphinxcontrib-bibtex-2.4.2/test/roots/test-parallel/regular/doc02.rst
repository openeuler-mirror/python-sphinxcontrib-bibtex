doc02
=====

:cite:`Sh:2`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
