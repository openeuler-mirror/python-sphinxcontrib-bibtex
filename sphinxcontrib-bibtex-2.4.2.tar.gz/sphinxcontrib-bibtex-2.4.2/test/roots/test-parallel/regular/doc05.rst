doc05
=====

:cite:`Sh:5`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
