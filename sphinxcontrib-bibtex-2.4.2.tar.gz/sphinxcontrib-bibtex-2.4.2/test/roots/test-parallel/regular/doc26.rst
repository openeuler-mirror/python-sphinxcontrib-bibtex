doc26
=====

:cite:`Sh:26`

