doc13
=====

:cite:`Sh:13`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
