doc24
=====

:cite:`Sh:24`

