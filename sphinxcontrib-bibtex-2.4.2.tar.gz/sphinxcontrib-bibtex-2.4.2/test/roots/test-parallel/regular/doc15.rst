doc15
=====

:cite:`Sh:15`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
