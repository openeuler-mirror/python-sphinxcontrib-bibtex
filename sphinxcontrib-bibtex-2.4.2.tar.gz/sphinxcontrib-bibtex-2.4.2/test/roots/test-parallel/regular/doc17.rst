doc17
=====

:cite:`Sh:17`

