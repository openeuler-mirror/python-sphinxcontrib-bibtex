doc18
=====

:cite:`Sh:18`

