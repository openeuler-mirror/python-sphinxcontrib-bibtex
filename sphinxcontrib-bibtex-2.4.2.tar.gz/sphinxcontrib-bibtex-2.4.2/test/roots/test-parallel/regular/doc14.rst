doc14
=====

:cite:`Sh:14`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
