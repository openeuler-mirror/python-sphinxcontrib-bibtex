allrefs
=======

.. bibliography::
   :filter: cited and not ({"regular/doc11", "regular/doc13", "regular/doc15"} & docnames)
