doc24
=====

:footcite:`Sh:1`

.. footbibliography::
