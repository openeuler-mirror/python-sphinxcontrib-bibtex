doc21
=====

:footcite:`Sh:1`

.. footbibliography::
