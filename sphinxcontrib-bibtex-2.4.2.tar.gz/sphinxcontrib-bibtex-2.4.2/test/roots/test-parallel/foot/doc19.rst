doc19
=====

:footcite:`Sh:1`

.. footbibliography::
