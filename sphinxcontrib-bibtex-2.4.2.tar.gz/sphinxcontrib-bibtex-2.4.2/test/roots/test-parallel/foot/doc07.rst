doc07
=====

:footcite:`Sh:1`

.. footbibliography::
