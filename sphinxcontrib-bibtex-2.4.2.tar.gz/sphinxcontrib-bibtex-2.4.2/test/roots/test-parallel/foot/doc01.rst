doc01
=====

:footcite:`Sh:1`

.. footbibliography::
