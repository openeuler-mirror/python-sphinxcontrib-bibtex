doc02
=====

:footcite:`Sh:1`

.. footbibliography::
