doc18
=====

:footcite:`Sh:1`

.. footbibliography::
