doc11
=====

:footcite:`Sh:1`

.. footbibliography::
