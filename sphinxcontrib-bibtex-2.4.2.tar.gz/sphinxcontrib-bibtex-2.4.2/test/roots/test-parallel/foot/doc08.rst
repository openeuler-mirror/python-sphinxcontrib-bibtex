doc08
=====

:footcite:`Sh:1`

.. footbibliography::
