extensions = ['sphinxcontrib.bibtex']
exclude_patterns = ['_build']
latex_documents = [
    ('index', 'test.tex',
     u'Test',
     u'Mr. Test', 'manual'),
]
bibtex_bibfiles = ['test.bib']
