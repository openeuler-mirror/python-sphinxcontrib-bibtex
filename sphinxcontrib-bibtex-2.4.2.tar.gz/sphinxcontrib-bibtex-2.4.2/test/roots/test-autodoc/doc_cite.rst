cite
====

.. automodule:: test.some_module_cite
   :members:

.. bibliography::
   :style: alpha
