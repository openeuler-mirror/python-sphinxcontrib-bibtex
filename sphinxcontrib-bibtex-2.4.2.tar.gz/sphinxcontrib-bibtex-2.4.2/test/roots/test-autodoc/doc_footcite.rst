footcite
========

.. automodule:: test.some_module_footcite
   :members:

.. footbibliography::
