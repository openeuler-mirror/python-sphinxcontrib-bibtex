extensions = ['sphinxcontrib.bibtex']
exclude_patterns = ['_build']
bibtex_default_style = 'plain'
bibtex_bibfiles = ['test.bib']
