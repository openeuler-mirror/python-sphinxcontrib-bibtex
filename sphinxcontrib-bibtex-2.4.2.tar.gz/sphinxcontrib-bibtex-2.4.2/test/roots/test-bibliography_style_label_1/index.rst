:cite:`myfancybibtexkey`
:cite:`myotherfancybibtexkey`

.. bibliography::
