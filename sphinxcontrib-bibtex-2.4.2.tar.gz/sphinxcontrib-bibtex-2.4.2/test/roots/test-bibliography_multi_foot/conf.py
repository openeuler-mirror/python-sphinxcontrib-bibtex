extensions = ['sphinxcontrib.bibtex']
exclude_patterns = ['_build']
bibtex_bibfiles = ['test.bib']
bibtex_footbibliography_header = '.. rubric:: Citations'
