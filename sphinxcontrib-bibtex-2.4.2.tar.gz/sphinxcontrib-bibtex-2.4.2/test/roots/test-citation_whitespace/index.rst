:cite:`first,
second`

.. bibliography::
   :style: alpha
