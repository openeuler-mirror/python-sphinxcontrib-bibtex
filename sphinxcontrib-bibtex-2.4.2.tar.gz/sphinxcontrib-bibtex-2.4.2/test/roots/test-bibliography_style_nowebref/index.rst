.. bibliography::
   :all:
   :list: bullet
