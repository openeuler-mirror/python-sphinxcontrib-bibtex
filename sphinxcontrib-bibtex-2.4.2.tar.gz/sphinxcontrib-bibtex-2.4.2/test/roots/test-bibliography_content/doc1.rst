doc1
====

:cite:`test1,test2`

.. bibliography::
   :filter: docname in docnames

   test2
   test3
