.. bibliography::
   :style: plain
   :all:
