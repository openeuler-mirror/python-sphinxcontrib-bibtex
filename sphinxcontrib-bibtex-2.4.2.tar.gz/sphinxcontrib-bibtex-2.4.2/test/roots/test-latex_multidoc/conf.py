extensions = ['sphinxcontrib.bibtex']
bibtex_bibfiles = ['sources.bib']
latex_documents = [
    ('index', 'test.tex',
     u'Test',
     u'Mr. Test', 'manual'),
]
