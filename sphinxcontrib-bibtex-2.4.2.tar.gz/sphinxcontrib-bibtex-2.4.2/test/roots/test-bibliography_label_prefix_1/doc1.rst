Doc1
====

:cite:`Test`

.. bibliography:: test1.bib
   :all:
   :style: plain
   :labelprefix: A
