First edition: :cite:`ABC_R1`.

Second edition: :cite:`ABC_R2`.

.. bibliography::
   :all:
