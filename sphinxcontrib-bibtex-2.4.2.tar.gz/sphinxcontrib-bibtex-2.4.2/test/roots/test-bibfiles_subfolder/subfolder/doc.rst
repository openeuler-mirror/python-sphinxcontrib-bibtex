Doc1
====

:cite:`Test`

.. bibliography::
   :style: plain
