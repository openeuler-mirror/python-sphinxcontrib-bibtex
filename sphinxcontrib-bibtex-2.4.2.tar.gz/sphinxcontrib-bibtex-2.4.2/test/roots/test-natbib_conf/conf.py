extensions = ['test.natbib']
exclude_patterns = ['_build']
natbib = {
    'file': 'test.bib',
    'brackets': '{}',
    'separator': '/',
    'style': 'authoryear',
}
