Doc2 [Test2]_
=============

Testing docutils citation in a title.

.. [Test2] The second test.