Doc1 :cite:`TestKey`
====================

Testing sphinxcontrib-bibtex citation in a title.