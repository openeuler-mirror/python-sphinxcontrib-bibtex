.. bibliography::
   :thisisintentionallyinvalid:
