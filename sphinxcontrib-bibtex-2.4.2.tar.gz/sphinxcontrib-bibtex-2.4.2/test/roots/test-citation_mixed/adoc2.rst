Doc2
====

[Test]_


.. [Test] This is a non-bibtex citation.