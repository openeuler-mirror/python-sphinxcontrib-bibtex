Contents
========

.. toctree::

   adoc1
   adoc2

.. bibliography::
   :style: plain
