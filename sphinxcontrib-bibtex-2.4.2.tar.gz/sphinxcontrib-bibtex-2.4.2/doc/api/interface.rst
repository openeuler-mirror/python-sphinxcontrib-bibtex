Sphinx Interface
================

.. automodule:: sphinxcontrib.bibtex
