New Docutils Nodes
==================

.. automodule:: sphinxcontrib.bibtex.nodes
