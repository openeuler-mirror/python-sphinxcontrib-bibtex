Bib Files
=========

.. automodule:: sphinxcontrib.bibtex.bibfile
