Plugins
=======

.. automodule:: sphinxcontrib.bibtex.plugin
   :members:
