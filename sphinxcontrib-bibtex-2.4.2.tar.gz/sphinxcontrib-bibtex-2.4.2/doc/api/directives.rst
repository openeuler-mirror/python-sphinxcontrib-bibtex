New Docutils Directives
=======================

.. automodule:: sphinxcontrib.bibtex.directives
.. automodule:: sphinxcontrib.bibtex.foot_directives
