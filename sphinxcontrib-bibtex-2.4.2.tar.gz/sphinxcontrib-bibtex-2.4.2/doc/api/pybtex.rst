Pybtex Extensions
=================

New Text Elements
-----------------

.. automodule:: sphinxcontrib.bibtex.richtext
   :members:

New Template Nodes
------------------

.. automodule:: sphinxcontrib.bibtex.style.template
   :members:

New Names Styles
----------------

.. automodule:: sphinxcontrib.bibtex.style.names.last
   :members:

