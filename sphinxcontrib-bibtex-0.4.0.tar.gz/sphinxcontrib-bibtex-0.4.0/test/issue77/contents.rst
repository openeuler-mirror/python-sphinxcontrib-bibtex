:cite:`2009:mandel`
:cite:`2003:evensen`

.. bibliography:: test.bib
   :style: apastyle
