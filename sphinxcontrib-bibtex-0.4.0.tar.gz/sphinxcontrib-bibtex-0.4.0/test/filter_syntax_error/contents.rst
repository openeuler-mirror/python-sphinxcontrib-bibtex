.. bibliography:: test.bib
   :filter: $

.. bibliography:: test.bib
   :filter: yield author

.. bibliography:: test.bib
   :filter: author is title

.. bibliography:: test.bib
   :filter: False % title

.. bibliography:: test.bib
   :filter: title % False

.. bibliography:: test.bib
   :filter: ~title

.. bibliography:: test.bib
   :filter: "2000" <= year <= "2005"

.. bibliography:: test.bib
   :filter: author + title

.. bibliography:: test.bib
   :filter: author; title
