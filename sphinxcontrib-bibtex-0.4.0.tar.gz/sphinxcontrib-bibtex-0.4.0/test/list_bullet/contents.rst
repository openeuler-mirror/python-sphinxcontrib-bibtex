.. bibliography:: test.bib
   :list: bullet
   :all:
