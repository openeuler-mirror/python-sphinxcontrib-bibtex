.. bibliography:: test.bib
   :list: bullet
   :filter: author % "Test"
