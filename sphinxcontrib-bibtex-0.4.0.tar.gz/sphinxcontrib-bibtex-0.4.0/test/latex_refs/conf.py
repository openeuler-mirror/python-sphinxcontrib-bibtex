extensions = ['sphinxcontrib.bibtex']
exclude_patterns = ['_build']
latex_documents = [
    ('contents', 'test.tex',
     u'Test',
     u'Mr. Test', 'manual'),
]
