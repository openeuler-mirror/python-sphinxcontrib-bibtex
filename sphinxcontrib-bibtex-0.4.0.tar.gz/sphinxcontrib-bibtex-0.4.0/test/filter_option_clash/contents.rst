.. bibliography:: test.bib
   :all:
   :cited:
   :notcited:
   :filter: author % "Troffaes"
