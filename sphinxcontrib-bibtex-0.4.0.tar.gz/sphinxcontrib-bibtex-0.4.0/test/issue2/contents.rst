Contents
========

.. toctree::

   adoc1
   adoc2

.. bibliography:: test.bib
   :style: plain
