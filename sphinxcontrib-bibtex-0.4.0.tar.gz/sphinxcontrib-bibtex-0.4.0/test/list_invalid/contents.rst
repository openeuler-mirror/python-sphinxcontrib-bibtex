.. bibliography:: test.bib
   :list: thisisintentionallyinvalid
