doc1
----

:cite:`tag1-2009:mandel`

.. bibliography:: test.bib
   :labelprefix: B
   :keyprefix: tag1-
