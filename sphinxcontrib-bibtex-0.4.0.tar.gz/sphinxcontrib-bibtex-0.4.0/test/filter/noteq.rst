NotEq
-----

.. bibliography:: test.bib
   :list: bullet
   :filter: year != "2011"
