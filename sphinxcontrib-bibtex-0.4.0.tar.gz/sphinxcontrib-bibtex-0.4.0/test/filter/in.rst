In
--

.. bibliography:: test.bib
   :list: bullet
   :filter: "bla" in docnames
