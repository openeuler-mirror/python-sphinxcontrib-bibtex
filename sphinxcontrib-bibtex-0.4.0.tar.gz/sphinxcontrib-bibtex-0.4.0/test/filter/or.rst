Or
--

.. bibliography:: test.bib
   :list: bullet
   :filter: author % "First" or type == "article"
