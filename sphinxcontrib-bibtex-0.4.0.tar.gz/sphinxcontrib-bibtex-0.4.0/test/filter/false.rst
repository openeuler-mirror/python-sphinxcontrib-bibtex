False
-----

.. bibliography:: test.bib
   :list: bullet
   :filter: False
