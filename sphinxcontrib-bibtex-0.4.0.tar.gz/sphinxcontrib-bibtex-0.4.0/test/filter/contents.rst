.. bibliography:: test.bib
   :list: bullet
   :filter: author % "Second" and type == "misc"

.. toctree::

   or
   noteq
   lt
   lte
   gt
   gte
   key
   false
   title
   in
   notin
   set
   bitand
   bitor
