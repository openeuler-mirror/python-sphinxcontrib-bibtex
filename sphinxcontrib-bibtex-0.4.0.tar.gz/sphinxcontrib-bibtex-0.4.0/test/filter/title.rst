Title
-----

.. bibliography:: test.bib
   :list: bullet
   :filter: title and title % "jakka"
