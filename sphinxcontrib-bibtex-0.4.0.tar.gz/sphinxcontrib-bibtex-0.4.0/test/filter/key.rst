Key
---

.. bibliography:: test.bib
   :list: bullet
   :filter: key == "third"
