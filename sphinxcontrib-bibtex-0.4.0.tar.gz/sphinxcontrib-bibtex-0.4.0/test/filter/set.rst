Set
---

.. bibliography:: test.bib
   :list: bullet
   :filter: {"doc1", "doc2"} <= docnames
