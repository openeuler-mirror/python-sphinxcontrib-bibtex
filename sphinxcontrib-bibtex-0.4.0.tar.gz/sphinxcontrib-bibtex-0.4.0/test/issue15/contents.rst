:cite:`first`
:cite:`second`

.. bibliography:: test.bib
   :style: unsrt
