:cite:`Test`

.. bibliography:: test.bib
   :all:
   :encoding: latex+utf
