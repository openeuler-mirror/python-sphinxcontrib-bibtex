.. automodule:: somemodule
   :members:
