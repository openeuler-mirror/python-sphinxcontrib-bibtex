"""Some module."""


def somefunction():
    """Some function."""
    pass
