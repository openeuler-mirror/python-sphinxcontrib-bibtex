.. bibliography:: test.bib
   :style: nowebref
   :all:
   :list: bullet
