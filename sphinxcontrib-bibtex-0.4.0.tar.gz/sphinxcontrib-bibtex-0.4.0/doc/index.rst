Welcome to sphinxcontrib-bibtex's documentation!
================================================

:Release: |release|
:Date:    |today|

Contents
--------

.. toctree::
   :maxdepth: 2

   quickstart
   usage
   api
   changes
   license
   related

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

