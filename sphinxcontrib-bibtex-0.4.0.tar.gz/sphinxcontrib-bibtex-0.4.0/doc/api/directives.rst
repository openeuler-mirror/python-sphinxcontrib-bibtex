.. automodule:: sphinxcontrib.bibtex.directives
