.. automodule:: sphinxcontrib.bibtex
