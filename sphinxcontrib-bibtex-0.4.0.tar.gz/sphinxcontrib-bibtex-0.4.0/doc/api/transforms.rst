.. automodule:: sphinxcontrib.bibtex.transforms
