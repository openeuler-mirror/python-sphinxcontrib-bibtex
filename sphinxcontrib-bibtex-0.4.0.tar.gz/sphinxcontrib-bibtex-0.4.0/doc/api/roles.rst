.. automodule:: sphinxcontrib.bibtex.roles
