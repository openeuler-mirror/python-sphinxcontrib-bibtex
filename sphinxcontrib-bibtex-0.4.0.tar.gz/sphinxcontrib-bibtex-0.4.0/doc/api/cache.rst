.. automodule:: sphinxcontrib.bibtex.cache
