.. automodule:: sphinxcontrib.bibtex.nodes
