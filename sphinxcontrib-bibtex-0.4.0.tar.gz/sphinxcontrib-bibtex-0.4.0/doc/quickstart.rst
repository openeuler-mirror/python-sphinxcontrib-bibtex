Getting Started
===============

Overview
--------

.. include:: ../README.rst
   :start-line: 5

Installation
------------

.. include:: ../INSTALL.rst
