License
=======

.. include:: ../LICENSE.rst

